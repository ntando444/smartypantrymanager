# Smart Pantry Manager — Written Report Template

> Replace every bracketed prompt. Add actual screenshots captured from your own running emulator/device. Do not claim that a feature worked until you have run and checked it. Use Times New Roman, 12 pt, 1.5 line spacing in the final Word/PDF document, Harvard-style citations, and the supplied institution cover page.

## Cover page

- Application: Smart Pantry Manager
- Student name: [Your name]
- Student ITS number: [Your number]
- Module: Mobile App Development 700
- Date: [Submission date]
- GitHub repository: [Public repository URL]

## Table of contents

[Generate this automatically in Word after applying heading styles.]

## 1. Introduction

[In your own words, describe the food-waste problem, who the app is for, and how requiring every ingredient already in the pantry addresses it.]

## 2. System design

### 2.1 Screen flow

```text
Pantry List
  ├── Add/Edit Ingredient
  ├── Suggested Recipes ── Recipe Detail
  └── Settings

Bottom navigation: Pantry List ↔ Suggested Recipes ↔ Settings
```

### 2.2 Data model

```text
pantry_items(id PK, name, quantity, unit, expiry_date)
recipes(id PK, name, summary, steps)
recipe_ingredients(id PK, recipe_id FK, name, quantity, unit)
app_settings(setting_key PK, setting_value)
```

[Explain the relationships and why the app uses SQLite on the device.]

## 3. Screenshots of the running application

Insert your own, legible screenshots. A source-code preview or mock-up is not evidence of a running app.

| Required screen or state | Insert actual screenshot | Caption / what it demonstrates |
| --- | --- | --- |
| Pantry list with saved items | [Insert screenshot] | [Explain list and persisted quantities] |
| Empty pantry state | [Insert screenshot] | [Explain first-use feedback] |
| Add ingredient form | [Insert screenshot] | [Explain fields] |
| Validation error | [Insert screenshot] | [Show and explain a real validation message] |
| Edit ingredient | [Insert screenshot] | [Show the saved value before and after editing] |
| Delete confirmation and result | [Insert screenshots] | [Show confirmation and removal] |
| Strict suggestions | [Insert screenshot] | [Name the pantry and matching recipes] |
| Missing-ingredient test | [Insert screenshots] | [Show a recipe disappear after removing one required item] |
| Recipe detail | [Insert screenshot] | [Show ingredients and method] |
| Settings | [Insert screenshot] | [Show saved settings] |
| Reopened app | [Insert screenshot] | [Show pantry data still present after restart] |

## 4. Key code snippets

Include 3–5 short snippets from your final code, with source file and line numbers. Select the exact code you understand and can explain.

1. **SQLite CRUD:** [Paste the relevant method]  
   [Explain how the insert/update/read/delete reaches SQLite.]

2. **Strict matching:** [Paste `IngredientMatcher.canMake` or the relevant final implementation]  
   [Explain why one missing ingredient or too-small quantity excludes the recipe.]

3. **RecyclerView adapter:** [Paste a short `onBindViewHolder` snippet]  
   [Explain how database records are bound to visible rows and how actions reach the Activity.]

4. **Intent navigation:** [Paste one short Intent snippet]  
   [Explain which value is passed and how the destination screen reads it.]

## 5. Challenges and solutions

Describe 2–3 real issues you personally encountered while building or testing. Do not use these prompts as claims unless they actually happened.

- Challenge: [What happened? Include the screen, data, or error.]  
  Solution: [What did you change and how did you confirm it worked?]
- Challenge: [Your real second issue.]  
  Solution: [Your real fix and verification.]

## 6. Conclusion and reflection

[Explain what you learned about Java Activities, Intents, RecyclerView, SQLite, and strict matching. Name one specific improvement you would make with more time.]

## 7. References

[List only sources you actually consulted. Use a consistent Harvard format, include access dates for online sources, and cite the sources in the body of the report.]

## Final checks

- [ ] Replace all bracketed prompts and personal details.
- [ ] Insert screenshots from the actual running application.
- [ ] Confirm every described behavior on the emulator/device.
- [ ] Add a working GitHub URL and verify the marker can access it.
- [ ] Apply the required font, size, spacing, and Harvard style.
- [ ] Sign the declaration on the institution's cover page yourself.
