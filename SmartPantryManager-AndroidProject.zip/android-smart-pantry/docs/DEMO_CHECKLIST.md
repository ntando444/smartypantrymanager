# 5–7 minute demonstration checklist

Use your own voice throughout the recording. Keep the screen readable and record at 1080p where possible. The outline below totals about 6 minutes; adjust timings to stay within the assignment's 5–7 minute limit.

## 0:00–1:00 — GitHub history

- Open your own public repository.
- Show the README and the chronological commit/push history.
- Explain the real development steps represented by those commits. Do not create backdated or artificial commits.

## 1:00–3:30 — Running application

- Show the pantry list and add a new ingredient with a quantity and unit.
- Edit that ingredient, then delete it.
- Add the ingredients needed for one known recipe and open Suggested Recipes.
- Remove one required ingredient; refresh Suggestions and show the recipe is excluded.
- Show the recipe detail page and settings.
- Close and reopen the app; show that pantry data persists.

## 3:30–5:30 — Explain three concepts in your own words

Choose three, point at the actual code in your repository, and explain them accurately:

- **Strict matching:** `IngredientMatcher.canMake` checks all requirements, normalizes names, converts supported units, and returns false when any amount is too small.
- **SQLite:** `PantryDbHelper` creates the tables and provides methods that insert, update, read, and delete records. Explain when the app reads the database again.
- **RecyclerView and Adapter:** `IngredientAdapter` binds ingredient objects to row views; button callbacks return edit/delete actions to the Activity.
- **Intents:** show an Activity launching another and passing an ingredient or recipe ID.
- **Activity lifecycle:** explain why the pantry is refreshed in `onResume` after returning from the edit screen.

Do not just read these notes. Rehearse an explanation you can defend.

## 5:30–6:00 — Why SQLite

Explain why local SQLite fits a single-device pantry app: offline use, persistent records, simple relational data, and no cloud account or server needed.

## Before recording

- Run the exact build you plan to demonstrate.
- Make sure the app has useful sample pantry data, and know which ingredient to remove for the strict-match test.
- Ensure the repository history is genuine and the source matches the running app.
- Verify audio is audible and the finished MP4 is within the ZIP's 50 MB limit.
