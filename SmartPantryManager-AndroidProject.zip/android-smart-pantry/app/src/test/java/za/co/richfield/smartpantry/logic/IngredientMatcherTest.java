package za.co.richfield.smartpantry.logic;

import org.junit.Test;
import za.co.richfield.smartpantry.model.Ingredient;
import za.co.richfield.smartpantry.model.Recipe;
import za.co.richfield.smartpantry.model.RecipeIngredient;

import java.util.Arrays;
import java.util.Collections;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class IngredientMatcherTest {
    @Test
    public void acceptsPluralAndUnitConversionWhenQuantityIsSufficient() {
        Recipe recipe = recipe("tomato", 1, "kg");
        assertTrue(IngredientMatcher.canMake(recipe, Collections.singletonList(
                new Ingredient(1, "tomatoes", 1100, "g", ""))));
    }

    @Test
    public void rejectsRecipeWhenAnyIngredientIsMissing() {
        Recipe recipe = new Recipe(1, "Omelette", "", "",
                Arrays.asList(new RecipeIngredient("egg", 2, "pieces"),
                        new RecipeIngredient("onion", 1, "piece")));
        assertFalse(IngredientMatcher.canMake(recipe,
                Collections.singletonList(new Ingredient(1, "eggs", 3, "pieces", ""))));
    }

    @Test
    public void rejectsInsufficientQuantity() {
        assertFalse(IngredientMatcher.canMake(recipe("milk", 500, "ml"),
                Collections.singletonList(new Ingredient(1, "milk", 0.4, "l", ""))));
    }

    private Recipe recipe(String name, double quantity, String unit) {
        return new Recipe(1, "Test", "", "",
                Collections.singletonList(new RecipeIngredient(name, quantity, unit)));
    }
}
