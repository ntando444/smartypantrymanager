package za.co.richfield.smartpantry.ui;

import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import android.widget.Toast;

import za.co.richfield.smartpantry.R;
import za.co.richfield.smartpantry.data.PantryDbHelper;
import za.co.richfield.smartpantry.model.Ingredient;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class AddEditIngredientActivity extends BaseActivity {
    public static final String EXTRA_INGREDIENT_ID = "ingredient_id";
    private PantryDbHelper database;
    private long ingredientId = -1;
    private EditText nameInput;
    private EditText quantityInput;
    private EditText unitInput;
    private EditText expiryInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit);
        bindBottomNavigation();
        database = new PantryDbHelper(this);
        nameInput = findViewById(R.id.ingredient_name);
        quantityInput = findViewById(R.id.ingredient_quantity);
        quantityInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        unitInput = findViewById(R.id.ingredient_unit);
        expiryInput = findViewById(R.id.ingredient_expiry);

        ingredientId = getIntent().getLongExtra(EXTRA_INGREDIENT_ID, -1);
        if (ingredientId >= 0) {
            findViewById(R.id.form_title).setContentDescription("Edit pantry ingredient");
            android.widget.TextView title = findViewById(R.id.form_title);
            title.setText("Edit ingredient");
            Ingredient existing = database.getIngredient(ingredientId);
            if (existing != null) {
                nameInput.setText(existing.getName());
                quantityInput.setText(String.valueOf(existing.getQuantity()));
                unitInput.setText(existing.getUnit());
                expiryInput.setText(existing.getExpiryDate());
            } else {
                finish();
                return;
            }
        }

        findViewById(R.id.save_ingredient_button).setOnClickListener(v -> save());
    }

    private void save() {
        String name = nameInput.getText().toString().trim();
        String quantityText = quantityInput.getText().toString().trim();
        String unit = unitInput.getText().toString().trim();
        String expiry = expiryInput.getText().toString().trim();

        if (name.isEmpty()) {
            nameInput.setError("Enter an ingredient name");
            nameInput.requestFocus();
            return;
        }
        if (quantityText.isEmpty()) {
            quantityInput.setError("Enter a quantity greater than zero");
            quantityInput.requestFocus();
            return;
        }
        final double quantity;
        try {
            quantity = Double.parseDouble(quantityText);
        } catch (NumberFormatException exception) {
            quantityInput.setError("Enter a valid number");
            quantityInput.requestFocus();
            return;
        }
        if (Double.isNaN(quantity) || Double.isInfinite(quantity) || quantity <= 0) {
            quantityInput.setError("Quantity must be greater than zero");
            quantityInput.requestFocus();
            return;
        }
        if (unit.isEmpty()) {
            unitInput.setError("Enter a unit, for example g, ml or pieces");
            unitInput.requestFocus();
            return;
        }
        if (!expiry.isEmpty() && !isValidDate(expiry)) {
            expiryInput.setError("Use a real date in YYYY-MM-DD format");
            expiryInput.requestFocus();
            return;
        }

        long savedId = database.saveIngredient(ingredientId, name, quantity, unit, expiry);
        if (savedId < 0) {
            Toast.makeText(this, "Could not save this ingredient. Please try again.",
                    Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, ingredientId < 0 ? "Ingredient added" : "Ingredient updated",
                Toast.LENGTH_SHORT).show();
        finish();
    }

    private boolean isValidDate(String value) {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.ROOT);
        format.setLenient(false);
        ParsePosition position = new ParsePosition(0);
        return format.parse(value, position) != null && position.getIndex() == value.length();
    }

    @Override
    protected void onDestroy() {
        database.close();
        super.onDestroy();
    }
}
