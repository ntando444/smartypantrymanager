package za.co.richfield.smartpantry.ui;

import android.content.Intent;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import za.co.richfield.smartpantry.R;

abstract class BaseActivity extends AppCompatActivity {
    protected void bindBottomNavigation() {
        View pantry = findViewById(R.id.nav_pantry);
        View recipes = findViewById(R.id.nav_recipes);
        View settings = findViewById(R.id.nav_settings);
        if (pantry != null) pantry.setOnClickListener(v -> navigate(MainActivity.class));
        if (recipes != null) recipes.setOnClickListener(v -> navigate(SuggestedRecipesActivity.class));
        if (settings != null) settings.setOnClickListener(v -> navigate(SettingsActivity.class));
    }

    private void navigate(Class<?> destination) {
        if (getClass().equals(destination)) return;
        Intent intent = new Intent(this, destination);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
    }
}
