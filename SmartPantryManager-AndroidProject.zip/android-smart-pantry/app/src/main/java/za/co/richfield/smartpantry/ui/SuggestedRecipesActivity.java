package za.co.richfield.smartpantry.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import za.co.richfield.smartpantry.R;
import za.co.richfield.smartpantry.data.PantryDbHelper;
import za.co.richfield.smartpantry.logic.IngredientMatcher;
import za.co.richfield.smartpantry.model.Recipe;

import java.util.ArrayList;
import java.util.List;

public class SuggestedRecipesActivity extends BaseActivity {
    private PantryDbHelper database;
    private RecipeAdapter adapter;
    private TextView emptyState;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_suggested);
        bindBottomNavigation();
        database = new PantryDbHelper(this);
        emptyState = findViewById(R.id.recipes_empty);
        RecyclerView list = findViewById(R.id.suggested_list);
        list.setLayoutManager(new LinearLayoutManager(this));
        adapter = new RecipeAdapter(recipe -> {
            Intent intent = new Intent(this, RecipeDetailActivity.class);
            intent.putExtra(RecipeDetailActivity.EXTRA_RECIPE_ID, recipe.getId());
            startActivity(intent);
        });
        list.setAdapter(adapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        List<Recipe> matches = new ArrayList<>();
        List<za.co.richfield.smartpantry.model.Ingredient> pantry = database.getPantryItems();
        for (Recipe recipe : database.getRecipes()) {
            if (IngredientMatcher.canMake(recipe, pantry)) matches.add(recipe);
        }
        adapter.setItems(matches);
        emptyState.setVisibility(matches.isEmpty() ? View.VISIBLE : View.GONE);
    }

    @Override
    protected void onDestroy() {
        database.close();
        super.onDestroy();
    }
}
