package za.co.richfield.smartpantry.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import za.co.richfield.smartpantry.R;
import za.co.richfield.smartpantry.model.Ingredient;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

class IngredientAdapter extends RecyclerView.Adapter<IngredientAdapter.ViewHolder> {
    interface Listener {
        void onEdit(Ingredient ingredient);
        void onDelete(Ingredient ingredient);
    }

    private final Listener listener;
    private final List<Ingredient> items = new ArrayList<>();
    private boolean expiryAlertsEnabled = true;

    IngredientAdapter(Listener listener) { this.listener = listener; }

    void setExpiryAlertsEnabled(boolean enabled) {
        expiryAlertsEnabled = enabled;
    }

    void setItems(List<Ingredient> newItems) {
        items.clear();
        items.addAll(newItems);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_ingredient, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Ingredient ingredient = items.get(position);
        holder.name.setText(ingredient.getName());
        String amount = ingredient.getQuantity() == Math.rint(ingredient.getQuantity())
                ? String.valueOf((long) ingredient.getQuantity())
                : String.valueOf(ingredient.getQuantity());
        String detail = amount + " " + ingredient.getUnit();
        if (!ingredient.getExpiryDate().isEmpty()) detail += "  ·  Expires " + ingredient.getExpiryDate();
        holder.detail.setText(detail);
        if (expiryAlertsEnabled) {
            String expiryStatus = expiryStatus(ingredient.getExpiryDate());
            if (!expiryStatus.isEmpty()) {
                holder.detail.append("  ·  " + expiryStatus);
                holder.detail.setTextColor(holder.itemView.getResources().getColor(R.color.danger));
            } else {
                holder.detail.setTextColor(holder.itemView.getResources().getColor(R.color.muted));
            }
        } else {
            holder.detail.setTextColor(holder.itemView.getResources().getColor(R.color.muted));
        }
        holder.edit.setOnClickListener(v -> listener.onEdit(ingredient));
        holder.delete.setOnClickListener(v -> listener.onDelete(ingredient));
    }

    private String expiryStatus(String dateText) {
        if (dateText == null || dateText.trim().isEmpty()) return "";
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.ROOT);
        format.setLenient(false);
        ParsePosition position = new ParsePosition(0);
        Date expiry = format.parse(dateText, position);
        if (expiry == null || position.getIndex() != dateText.length()) return "";

        Calendar today = Calendar.getInstance();
        clearTime(today);
        Calendar expiryDay = Calendar.getInstance();
        expiryDay.setTime(expiry);
        clearTime(expiryDay);
        if (expiryDay.before(today)) return "Expired";

        Calendar soonLimit = (Calendar) today.clone();
        soonLimit.add(Calendar.DAY_OF_YEAR, 3);
        return expiryDay.compareTo(soonLimit) <= 0 ? "Expiring soon" : "";
    }

    private void clearTime(Calendar calendar) {
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
    }

    @Override public int getItemCount() { return items.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView name;
        final TextView detail;
        final Button edit;
        final Button delete;
        ViewHolder(View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.ingredient_row_name);
            detail = itemView.findViewById(R.id.ingredient_row_detail);
            edit = itemView.findViewById(R.id.edit_ingredient_button);
            delete = itemView.findViewById(R.id.delete_ingredient_button);
        }
    }
}
