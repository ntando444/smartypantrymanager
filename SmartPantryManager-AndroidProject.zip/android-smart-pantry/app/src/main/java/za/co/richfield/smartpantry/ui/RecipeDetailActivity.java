package za.co.richfield.smartpantry.ui;

import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import za.co.richfield.smartpantry.R;
import za.co.richfield.smartpantry.data.PantryDbHelper;
import za.co.richfield.smartpantry.model.Recipe;
import za.co.richfield.smartpantry.model.RecipeIngredient;

public class RecipeDetailActivity extends BaseActivity {
    public static final String EXTRA_RECIPE_ID = "recipe_id";
    private PantryDbHelper database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_detail);
        bindBottomNavigation();
        database = new PantryDbHelper(this);

        long id = getIntent().getLongExtra(EXTRA_RECIPE_ID, -1);
        Recipe recipe = database.getRecipe(id);
        if (recipe == null) {
            finish();
            return;
        }
        ((TextView) findViewById(R.id.detail_recipe_name)).setText(recipe.getName());
        ((TextView) findViewById(R.id.detail_recipe_summary)).setText(recipe.getSummary());
        ((TextView) findViewById(R.id.detail_steps)).setText(recipe.getSteps());
        LinearLayout ingredients = findViewById(R.id.detail_ingredients);
        for (RecipeIngredient ingredient : recipe.getIngredients()) {
            TextView row = new TextView(this);
            row.setText("•  " + ingredient.displayText());
            row.setTextSize(16);
            row.setTextColor(getResources().getColor(R.color.ink));
            row.setPadding(0, 10, 0, 10);
            ingredients.addView(row);
        }
    }

    @Override
    protected void onDestroy() {
        database.close();
        super.onDestroy();
    }
}
