package za.co.richfield.smartpantry.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import za.co.richfield.smartpantry.R;
import za.co.richfield.smartpantry.model.Recipe;

import java.util.ArrayList;
import java.util.List;

class RecipeAdapter extends RecyclerView.Adapter<RecipeAdapter.ViewHolder> {
    interface OnRecipeClick { void onClick(Recipe recipe); }
    private final OnRecipeClick onClick;
    private final List<Recipe> items = new ArrayList<>();

    RecipeAdapter(OnRecipeClick onClick) { this.onClick = onClick; }

    void setItems(List<Recipe> newItems) {
        items.clear();
        items.addAll(newItems);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_recipe, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Recipe recipe = items.get(position);
        holder.name.setText(recipe.getName());
        holder.summary.setText(recipe.getSummary());
        holder.ingredientCount.setText(recipe.getIngredients().size() + " ingredients available");
        holder.itemView.setOnClickListener(v -> onClick.onClick(recipe));
    }

    @Override public int getItemCount() { return items.size(); }

    static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView name;
        final TextView summary;
        final TextView ingredientCount;
        ViewHolder(View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.recipe_row_name);
            summary = itemView.findViewById(R.id.recipe_row_summary);
            ingredientCount = itemView.findViewById(R.id.recipe_row_count);
        }
    }
}
