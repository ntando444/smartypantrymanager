package za.co.richfield.smartpantry.model;

import java.util.List;

public class Recipe {
    private final long id;
    private final String name;
    private final String summary;
    private final String steps;
    private final List<RecipeIngredient> ingredients;

    public Recipe(long id, String name, String summary, String steps,
                  List<RecipeIngredient> ingredients) {
        this.id = id;
        this.name = name;
        this.summary = summary;
        this.steps = steps;
        this.ingredients = ingredients;
    }

    public long getId() { return id; }
    public String getName() { return name; }
    public String getSummary() { return summary; }
    public String getSteps() { return steps; }
    public List<RecipeIngredient> getIngredients() { return ingredients; }
}
