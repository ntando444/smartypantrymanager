package za.co.richfield.smartpantry.ui;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Switch;

import za.co.richfield.smartpantry.R;
import za.co.richfield.smartpantry.data.PantryDbHelper;

public class SettingsActivity extends BaseActivity {
    private PantryDbHelper database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        bindBottomNavigation();
        database = new PantryDbHelper(this);

        Switch expiryAlerts = findViewById(R.id.expiry_alerts_switch);
        expiryAlerts.setChecked(database.getExpiryAlertsEnabled());
        expiryAlerts.setOnCheckedChangeListener((button, checked) ->
                database.setExpiryAlertsEnabled(checked));

        Spinner units = findViewById(R.id.units_spinner);
        ArrayAdapter<CharSequence> choices = ArrayAdapter.createFromResource(this,
                R.array.unit_preferences, android.R.layout.simple_spinner_item);
        choices.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        units.setAdapter(choices);
        String selected = database.getPreferredUnits();
        int index = selected.equals("US customary") ? 1 : 0;
        units.setSelection(index);
        units.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent,
                                       android.view.View view, int position, long id) {
                database.setPreferredUnits(position == 1 ? "US customary" : "Metric");
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        });
    }

    @Override
    protected void onDestroy() {
        database.close();
        super.onDestroy();
    }
}
