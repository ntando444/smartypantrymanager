package za.co.richfield.smartpantry.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import za.co.richfield.smartpantry.R;
import za.co.richfield.smartpantry.data.PantryDbHelper;
import za.co.richfield.smartpantry.model.Ingredient;

import java.util.List;

public class MainActivity extends BaseActivity implements IngredientAdapter.Listener {
    private PantryDbHelper database;
    private IngredientAdapter adapter;
    private TextView emptyState;
    private TextView countLabel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindBottomNavigation();
        database = new PantryDbHelper(this);
        emptyState = findViewById(R.id.pantry_empty);
        countLabel = findViewById(R.id.pantry_count);

        RecyclerView pantryList = findViewById(R.id.pantry_list);
        pantryList.setLayoutManager(new LinearLayoutManager(this));
        adapter = new IngredientAdapter(this);
        pantryList.setAdapter(adapter);

        findViewById(R.id.add_ingredient_button).setOnClickListener(v ->
                startActivity(new Intent(this, AddEditIngredientActivity.class)));
        findViewById(R.id.suggest_button).setOnClickListener(v ->
                startActivity(new Intent(this, SuggestedRecipesActivity.class)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshPantry();
    }

    private void refreshPantry() {
        List<Ingredient> items = database.getPantryItems();
        adapter.setExpiryAlertsEnabled(database.getExpiryAlertsEnabled());
        adapter.setItems(items);
        countLabel.setText(items.size() + (items.size() == 1 ? " ingredient saved" : " ingredients saved"));
        emptyState.setVisibility(items.isEmpty() ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onEdit(Ingredient ingredient) {
        Intent intent = new Intent(this, AddEditIngredientActivity.class);
        intent.putExtra(AddEditIngredientActivity.EXTRA_INGREDIENT_ID, ingredient.getId());
        startActivity(intent);
    }

    @Override
    public void onDelete(Ingredient ingredient) {
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Delete " + ingredient.getName() + "?")
                .setMessage("This removes the ingredient from your pantry.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (dialog, which) -> {
                    database.deleteIngredient(ingredient.getId());
                    refreshPantry();
                })
                .show();
    }

    @Override
    protected void onDestroy() {
        database.close();
        super.onDestroy();
    }
}
